<?php
	$db_username = 'root';
	$db_password = '';
		try {
			$conn = new PDO( 'mysql:host=localhost;', $db_username, $db_password);
			echo "connected <br/>";
			} catch(PDOException $e){
             echo "SALAM";
			}
?>